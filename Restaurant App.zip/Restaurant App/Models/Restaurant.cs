﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurant_App.Models
{
    public class Restaurant
    {
        public Restaurant (int rank)
        {
            Rank = rank;
        }

        [Required]
        public int Rank { get; set; }
        [Required]
        public string? RestaurantName { get; set; } = "It’s all tasty!";
        public string FavoriteDish { get; set; }
        [Required]
        public string Address { get; set; }
        public string RestaurantPhone { get; set; }
        public string? WebsiteLink { get; set; } = "Coming soon";


        public static Restaurant[] GetRestaurants()
        {
            Restaurant r1 = new Restaurant(1)
            {
                RestaurantName = "The Holy Grill",
                FavoriteDish = "Pulled Pork Sandwich",
                Address = "322 E State Rd, Pleasant Grove, UT 84062",
                RestaurantPhone = "(801) 701-0097",
                WebsiteLink = "http://www.theholygrillandbar.com/"
            };
            Restaurant r4 = new Restaurant(4)
            {
                RestaurantName = "Two Jack's Pizza",
                FavoriteDish = "Jack's Combo Pizza",
                Address = "80 W Center St, Provo, UT 84601",
                RestaurantPhone = "(801) 377-4747",
                WebsiteLink = "https://www.twojackspizza.com/"
            };
            Restaurant r3 = new Restaurant(3)
            {
                RestaurantName = "Koko Lunchbox",
                FavoriteDish = "Spicy Chicken Dupbop",
                Address = "1175 N Canyon Rd #3420, Provo, UT 84604",
                RestaurantPhone = "(801) 850-4358",
                WebsiteLink = "https://m.facebook.com/kokobobox/"
            };
            Restaurant r5 = new Restaurant(5)
            {
                RestaurantName = "Don Chuy's Taco Shop",
                FavoriteDish = "Carne Asada Fries",
                Address = "520 900 E, Provo, UT 84606",
                RestaurantPhone = "(801) 607-1519",
                WebsiteLink = "https://www.donchuys.com/"
            };
            Restaurant r2 = new Restaurant(2)
            {
                RestaurantName = "DP Cheesesteaks",
                FavoriteDish = "Hot Pepper Steak Sandwich",
                Address = "1774 N University Pkwy, Provo, UT 84604",
                RestaurantPhone = "(801) 709-2996",
                WebsiteLink = "http://www.dpcheesesteaks.com/"
            };

            return new Restaurant[] { r1, r2, r3, r4, r5 };
        }

    }
}
