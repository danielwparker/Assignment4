﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Restaurant_App.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurant_App.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<string> restaurantList = new List<string>();
            foreach (Restaurant r in Restaurant.GetRestaurants())
            {
                restaurantList.Add(string.Format("#{0} {1}\nFavorite Dish: {2}\nAddress: {3}\nPhone: {4}\n{5}", r.Rank, r.RestaurantName, r.FavoriteDish, r.Address, r.RestaurantPhone, r.WebsiteLink));
            }

            

            return View(restaurantList);
        }

        [HttpGet]
        public IActionResult AddSuggestion()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddSuggestion(Suggestion suggestion)
        {
            TempStorage.AddSuggestion(suggestion);
            return View("Confirmation", suggestion);
        }

        public IActionResult SuggestionList()
        {
            return View(TempStorage.Suggestions);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
